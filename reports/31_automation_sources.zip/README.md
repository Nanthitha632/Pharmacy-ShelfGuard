﻿# Pharmacy ShelfGuard

A synthetic pharmacy supply chain simulation. No real pharmacy or patient data.

## Where things go
- python/ — saved programs that create data, forecast demand, and test decisions
- sql/ — saved PostgreSQL table definitions and reusable queries
- data/raw/ — generated source records
- data/processed/ — validated or transformed datasets
- reports/ — saved metrics and simulation results
- powerbi/ — dashboard file
- docs/ — business rules, decisions, and interview notes

## Working rule
Save each useful program or query as a named file. Run the file; do not replace
its contents with the next piece of code. Record important findings in docs/.
